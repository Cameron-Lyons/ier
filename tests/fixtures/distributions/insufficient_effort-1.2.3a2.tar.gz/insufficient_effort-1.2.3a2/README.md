Distribution verifier fixture.
