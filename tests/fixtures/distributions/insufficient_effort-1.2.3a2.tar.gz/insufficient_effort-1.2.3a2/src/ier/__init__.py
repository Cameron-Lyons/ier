"""Distribution verifier fixture."""
